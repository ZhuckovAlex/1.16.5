package net.magforest.magforest.init;

import net.magforest.magforest.items.MaterialItem;
import net.magforest.magforest.magforest;
import net.minecraft.item.Item;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, magforest.MOD_ID);
    public static final RegistryObject<Item> DEREVO = ITEMS.register("derevo", MaterialItem::new);
}
