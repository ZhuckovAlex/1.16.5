package net.magforest.magforest.items;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;

public class MaterialItem extends Item{
    public MaterialItem() {
        super(new Item.Properties().tab(ItemGroup.TAB_MATERIALS));
    }
}
